import time, os
try:
    import requests
except ImportError:
    os.system('pip install requests')
from http.cookiejar import LWPCookieJar as kuki
from getpass import getpass

def cek():
	try:
		s.cookies=kuki('cookie/cookies')
		s.cookies.load()
		cek=s.get('https://mbasic.facebook.com/me').text
		if 'mbasic_logout_button' in cek:
			b='True'
			return b
		else:
                    print('[!] mati Invalid ')
                    os.remove('cookie/cookies')
                    b='False'
                    return b
	except:
		print('[!] cookies invalid')
		os.remove('cookie/cookies')
		b='False'
		return b

def login(self):
	global s
	time.sleep(1)
	s = self.req
	s.cookies = kuki('cookie/cookies')
	try:
		fil=open('cookie/cookies')
		fil.close()
	except FileNotFoundError:
		print("[!] Cookies not found\n\n[!] Please login in your facebook once again")
		email=input('[?] email/username: ')
		pw=getpass('[?] password: ')
		data = {'email':email,'pass':pw}
		res = s.post('https://mbasic.facebook.com/login',data=data).text
		if 'm_sess' in str(res) or 'save-device' in str(res):
			s.cookies.save()
		else:
			exit('[!] Fail login into your account')
	if 'True' in cek():
		pass
	else:
		exit()
